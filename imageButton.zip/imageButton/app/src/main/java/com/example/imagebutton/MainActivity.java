package com.example.imagebutton;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declaring the variable for image button
    ImageButton gfgImageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing the variable for image button
        gfgImageButton =  (ImageButton) findViewById(R.id.imageButton);

        // Below code is for setting a click listener on the image
        gfgImageButton.setOnClickListener(view -> {
            // Creating a toast to display the message
            Toast.makeText(MainActivity.this, "ei tapahdu yhtään mitään", Toast.LENGTH_SHORT).show();
        });
    }
}